# Abstract

<b>Problem:</b> Organize ever-evolving, big and cluttered personal social networks.

<b>Data:</b> While some users manually categorize their social circles (the map friends to categories) they are laborious to construct.

<b>Goal:</b> Automation of users’ social circles.

Framing the problem: Node clustering (on a user’s ego-network)
Model: Network structure + Profile information
For each circle, we learn its members and the circle-specific user profile similarity matrix.

# Introduction
***
Social circles
Ego: User for which we compute the social circles
Alters: User's friends

Two useful sources of data. The first is the set of edges
of the ego-network. We expect that circles are formed by densely-connected sets of alters [20].

Frequent overlap and concentric circles -> Detect multiple circles

circle affiliations as latent variables, and similarity between alters as a function of common profile information

latent variables (from Latin: present participle of lateo (“lie hidden”), as opposed to observable variables), are variables that are not directly observed but are rather inferred
***

Unsupervised method to learn which dimensions of profile similarity lead to densely linked circles.
- Mixed membership models [2] we predict hard assignment of a node to multiple circles, which proves critical for good performance.
- Parameterized definition of profile similarity, we learn the dimensions of similarity along which links emerge.

This extends the notion of homophily [12] by allowing different circles to form along different social dimensions, an idea related to the concept of Blau spaces [16]


# A Generative Model for Friendships in Social Circles

Model of circle formation with the following properties

- Nodes within circles should have common properties, or ‘aspects’.

- Different circles should be formed by different aspects (family, job, friends)

- Circles should be allowed to overlap, and ‘stronger’ circles should be allowed to form within ‘weaker’ ones, e.g. a circle of friends from the same degree program may form within a circle from the same university

- We would like to leverage both profile information and network structure in order to identify the circles. Ideally we would like to be able to pinpoint which aspects of a profile caused a circle to form, so that the model is interpretable by the user.

Input:
- Ego network G = (V, E) where the user is not in the network, along with profiles $\forall v \in V$.

Output:
- For each ego-network, our goal is to predict a set of
circles $\mathcal{C}=\{ C_{1}, ..., C_{K} \}$, $C_{k} \in V$
- Associated parameter vectors $\theta_{k}$ that encode how each circle
emerged.

Note: We encode user profiles into pairwise features $\phi(x, y)$ (properties the users x and y have in common).


Treats circle memberships as latent variables =>
"Nodes within a common circle are given an opportunity to form an edge, which naturally leads to hierarchical and overlapping circles."

unsupervised algorithm to jointly optimize the latent variables and the profile similarity parameters so as to best explain the observed network data.

# Algorithms

On this particular problem, many algorithms were benchmarked and studied (exhaustive list in the table below).

|                  Models                  |     Type     | Ranking |
|:----------------------------------------:|:------------:|:-------:|
| K-means clustering                       |      ML      |    NA   |
| Multi-Assignment Clustering              |      ML      |  Top 3  |
| Link clustering                          |    Network   |    NA   |
| Clique percolation                       |    Network   |    NA   |
| Mixed Membership Stochastic Block Models | Network + ML |    NA   |
| Block-LDA                                | Network + ML |  Top 2  |
| Low-Rank Embedding                       | Network + ML |  Top 4  |
| Main paper algo                          | Network + ML |  Top 1  |

In this section, we give an overview of the algorithms landscape and select some to implement and study in-depth.

Note: We will solely focus on algorithms which incorporate network science in this project.

Our approach will be three-fold. Specifically, we will:

1. Perform a thorough analysis of the graph (nodes and edges, connectedness, degree distributon) to better understand the underlying topology of the network.
2. Implement baseline algorithms seen in class (link clustering and clique percolation) to the data and confront them with ground truths.
3. Provide a detailed and intuitive explanation of state of the art techniques such as Block-Latent Dirichlet Allocation and low-rank embedding.
4. If time permits, we will explore the current state of the art model, which is based on unsupervised learning of learning parameters on top of a generative model for friendship in social circles.

# Evaluation

We will use the $f_{1}$ score for all models applied here as it is convenient for both supervised and unsupervised setting.

As most

Unsupervised: Evaluate it on ground-truth data by examining the maximum-likelihood assignments of the latent circles $C = {C_{1}, . . ., C_{K}}$ after convergence.

Our goal is that for a properly regularized model, the latent variables will align closely with the human labeled ground-truth circles $\hat{C}= \{\hat{C}_{1} . . . \hat{C}_{K}¯\}$.

Evaluation metrics:
- Balanced Error Rate (BER) between the two circles $C$ and $\hat{C}$:
$$
BER(C, \hat{C}) = \frac{1}{2}(\frac{C\\ \hat{C} }{C} + \frac{C^{c}\\ \hat{C}^{c} }{C^{c}})
$$

We choose this measure because it assigns equal importance to false positives and false negatives, so that trivial or random predictions incur an error of 0.5 on average. Such a measure is preferable to the 0/1 loss (for example), which assigns extremely low error to trivial predictions.

Report the F1 score, which we find produces qualitatively similar results.

# Baseline

- Only network:
  * Mixed Membership Stochastic Block Models (MMSBM): predict a stochastisc  vector encoding partial circle memberships, which we threshold to generate ‘hard’ assignments

- Only profile informations
  * ML: K-means + Hierarchical clustering
  * Multi-Assignment Clustering (+++): predicts hard assignments to multiple clusters

- Both:
  * Low-Rank Embedding (+++):  node attributes and edge information are projected into a feature space
  * Block-LDA (+++): jointly modeling links and text about the entities that are linked
  * Main paper algo (+++)
  * MMSBM variants with text data




# Sources
[Mixed membership model](https://pdfs.semanticscholar.org/f0f1/292719f02a59990a7fd4a35b97de85be1c11.pdf)
