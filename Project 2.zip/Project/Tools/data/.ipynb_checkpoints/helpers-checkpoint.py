import os
import networkx as nx

def read_egos():
    ego_namfriends_id = os.listdir('data/egonets/')
    egos = {}
    for ego in ego_namfriends_id:
        number, name = ego.split('.')
        egos[number] = read_ego('data/egonets/' + ego)
    print('Egonets imported : ' + str(len(ego_namfriends_id)))
    return egos

def read_circles():
    ego_namfriends_id = os.listdir('data/Training/')
    egos = {}

    for ego in ego_namfriends_id:
        egos[ego[:-8]] = read_circle('data/Training/' + ego)

    print('Circle friends_id imported : ' + str(len(ego_namfriends_id)))
    return egos

def read_circle(filename):
    # Instanciate graph
    G = nx.Graph()
    
    # Read file line by line
    for line in open(filename):
        # Split the line into the user ID and his friends IDs
        user_id, friends_id = line.split(':')
        friends_id = friends_id.split()
        print(line)
        user_id = user_id[6:]

        # Add nodes and edges sequentially
        for friend in friends_id:
            G.add_node(int(friend))
            if friend == user_id:
                break
            else:
                G.add_edge(int(user_id), int(friend))

    return(G)

def read_ego(filename):
    # Instanciate graph
    G = nx.Graph()

    # Read file line by line
    for line in open(filename):
        # Split the line into the user ID and his friends IDs
        user_id, friends_id = line.split(':')
        friends_id = friends_id.split()

        # Add nodes and edges sequentially
        for friend in friends_id:
            G.add_node(int(friend))
            if friend == user_id:
                break
            else:
                G.add_edge(int(user_id), int(friend))
    return G
