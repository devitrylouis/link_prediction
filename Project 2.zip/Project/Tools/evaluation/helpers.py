import networkx as nx

def true_labels(circle):
    return([set(l) for l in list(circle.values())])

def complete_partition(circle, ego, prediction, change = True):
    """
    Make community predictions cover the whole ego.
    """
    # Create missing community
    missing_community = []
    # Add nodes to missing community if node missing from prediction
    for node in ego.nodes():
        if str(node) not in [item for l in prediction for item in l]:
            missing_community.append(node)

    # If there is a missing community, add it to prediction
    if(len(missing_community) > 0 and change):
        prediction.append(set(missing_community))

    predicted = [set([str(i) for i in pred]) for pred in prediction]

    return predicted
