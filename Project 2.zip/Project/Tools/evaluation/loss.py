import os
from collections import defaultdict
import random
from pylab import *
import sys
from munkres import Munkres
import numpy

# Compute the loss for one user (i.e., one set of circles for one ego-network)
# usersPerCircle: list of sets of users (groundtruth). Order doesn't matter.
# usersPerCircleP: list of sets of users (predicted). Order doesn't matter.
# Compute the loss for one user (i.e., one set of circles for one ego-network)
# usersPerCircle: list of sets of users (groundtruth). Order doesn't matter.
# usersPerCircleP: list of sets of users (predicted). Order doesn't matter.
def loss_kaggle(usersPerCircle, usersPerCircleP):
    # psize: either the number of groundtruth, or the number of predicted circles (whichever is larger)
    psize = max(len(usersPerCircle), len(usersPerCircleP)) # Pad the matrix to be square

    # mm: matching matrix containing costs of matching groundtruth circles to predicted circles.
    #     mm[i][j] = cost of matching groundtruth circle i to predicted circle j
    mm = np.zeros((psize, psize))

    # mm2: copy of mm since the Munkres library destroys the data during computation
    mm2 = np.zeros((psize, psize))

    for i in range(psize):
        for j in range(psize):
            circleP = set() # Match to an empty circle (delete all users)
            circle = set() # Match to an empty circle (add all users)
            if (i < len(usersPerCircleP)):
                circleP = usersPerCircleP[i]
            if (j < len(usersPerCircle)):
                circle = usersPerCircle[j]
            nedits = len(circle.union(circleP)) - len(circle.intersection(circleP)) # Compute the edit distance between the two circles
            mm[i][j] = nedits
            mm2[i][j] = nedits

    if psize == 0:
        return 0 # Edge case in case there are no circles
    else:
        m = Munkres()
        #print mm2 # Print the pairwise cost matrix
        indices = m.compute(mm) # Compute the optimal alignment between predicted and groundtruth circles
        editCost = 0
        for row, column in indices:
            #print row,column # Print the optimal value selected by matching
            editCost += mm2[row][column]

    return int(editCost)
