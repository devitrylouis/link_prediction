import numpy as np
from scipy.optimize import linear_sum_assignment


def precision_com(C, C_):
    scores = np.zeros((len(C), len(C_)))
    for i, c in enumerate(C):
        for j, c_ in enumerate(C_):
            scores[i, j] = len(set(c).intersection(set(c_))) / float(len(set(c)))
    return(scores)

def recall_com(C, C_):
    scores = np.zeros((len(C), len(C_)))
    for i, c in enumerate(C):
        for j, c_ in enumerate(C_):
            scores[i, j] = len(set(c).intersection(set(c_))) / float(len(set(c_)))
    return(scores)

def f1_com(C, C_):
    scores = np.zeros((len(C), len(C_)))
    precision = precision_com(C, C_)
    recall = recall_com(C, C_)
    for i, c in enumerate(C):
        for j, c_ in enumerate(C_):
            numerator = 2 * precision[i, j] * recall[i, j]
            denominator = precision[i, j] + recall[i, j]
            scores[i, j] = numerator/float(denominator)
    return(scores)

def balanced_error_rate(C, C_):
    scores = np.zeros((len(C), len(C_)))
    for i, c in enumerate(C):
        for j, c_ in enumerate(C_):
            first_term = len(set(c).difference(c_))/float(len(c))
            second_term = len(set(c_).difference(c))/float(len(c_))
            scores[i, j] = 0.5*(first_term + second_term)
    return(scores)

def best_matching_evaluation(C, C_):
    # Get similarity score
    scores = balanced_error_rate(C, C_)
    best_matching = 0

    # Temporary computations
    pred_loss = []
    true_loss = []

    for i, c_ in enumerate(C_):
        pred_loss.append(np.amax(scores[:,i]))
    for i, c in enumerate(C):
        true_loss.append(np.amax(scores[i,:]))

    best_matching += sum(pred_loss)/float(2*len(C_))
    best_matching += sum(true_loss)/float(2*len(C))

    return(best_matching)

def hungarian_evaluation(C, C_):
    # Get similarity score
    scores = balanced_error_rate(C, C_)
    matching = linear_sum_assignment(scores)

    result = 0
    for i in list(matching[0]):
        for j in list(matching[1]):
            result += scores[i, j]
    result = result / float(min(len(C), len(C_))**2)
    return(result)
